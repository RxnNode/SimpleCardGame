package SimpleCardGame;

public class Controller {
}
